Imports System.IO
Imports System.Diagnostics


Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem3})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem7, Me.MenuItem4, Me.MenuItem8, Me.MenuItem2})
        Me.MenuItem1.Text = "File"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 0
        Me.MenuItem7.Text = "String Replace"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 1
        Me.MenuItem4.Text = "Process Input File"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 2
        Me.MenuItem8.Text = "-"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 3
        Me.MenuItem2.Text = "Exit"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem5, Me.MenuItem6})
        Me.MenuItem3.Text = "Help"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 0
        Me.MenuItem5.Text = "Help File"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 1
        Me.MenuItem6.Text = "About"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.DefaultExt = "txt"
        Me.OpenFileDialog1.Title = "Select an input file to parse"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(24, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(256, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Total Files Processed:"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(24, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(256, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Total Files Renamed:"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(24, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(256, 23)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Total Rename Fails:"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label4.Location = New System.Drawing.Point(40, 112)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(240, 23)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Invalid Source Files:"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label5.Location = New System.Drawing.Point(40, 136)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(240, 23)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Destination Already Exists:"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label6.Location = New System.Drawing.Point(40, 88)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(240, 23)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Invalid Character Sequence:"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabel1.Location = New System.Drawing.Point(24, 160)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(100, 16)
        Me.LinkLabel1.TabIndex = 6
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "View Log File"
        Me.LinkLabel1.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Location = New System.Drawing.Point(8, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(280, 192)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(304, 256)
        Me.Panel1.TabIndex = 8
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Location = New System.Drawing.Point(8, 0)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(280, 192)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        '
        'FolderBrowserDialog1
        '
        Me.FolderBrowserDialog1.Description = "Select the folder to be processed."
        Me.FolderBrowserDialog1.ShowNewFolderButton = False
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(296, 222)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(304, 256)
        Me.Menu = Me.MainMenu1
        Me.MinimumSize = New System.Drawing.Size(304, 256)
        Me.Name = "Form1"
        Me.Text = "Simple File Renamer 1.0"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    

    Private Sub Rename_File_Process()
        Try
            Panel1.Visible = True
            Dim result As DialogResult = OpenFileDialog1.ShowDialog()
            If result = DialogResult.OK Then
                Dim filereader As New StreamReader(OpenFileDialog1.FileName, True)
                Dim lineread As String = filereader.ReadLine
                Dim destread As String
                Dim filetomanipulate As File
                Dim Count_Total, Count_Renamed, Count_Failed_Source, Count_Failed_Destination, Count_Failed_Invalid_Character As Integer
                Count_Total = 0
                Count_Renamed = 0
                Count_Failed_Source = 0
                Count_Failed_Destination = 0
                Count_Failed_Invalid_Character = 0

                Dim f As FileInfo
                f = New FileInfo(Application.ExecutablePath())

                Dim filewriter As New StreamWriter(f.DirectoryName() & "\logfile.htm", False, System.Text.Encoding.ASCII)



                filewriter.WriteLine("<html>" & vbCrLf & "<body bgproperties=""fixed"" background=""" & f.DirectoryName() & "/Background_Image_Log_File.jpg" & """>" & vbCrLf & "<h1>Simple File Renamer 1.0 Log File</h1>")
                filewriter.WriteLine("<h3>Process Started: " & Now & "</h3>")
                filewriter.WriteLine("<p>Input File: " & OpenFileDialog1.FileName & "</p>")
                filewriter.WriteLine("<ul>")
                Do While Not lineread Is Nothing
                    lineread = lineread.Trim()
                    destread = filereader.ReadLine
                    If (Not lineread Is Nothing) And (Not destread Is Nothing) Then


                        Count_Total = Count_Total + 1
                        Dim target As String = "/*?""<>|"
                        Dim anyOf As Char() = target.ToCharArray()
                        filewriter.WriteLine("<li>Source: " & lineread & "<br>")
                        filewriter.WriteLine("Destination: " & destread & "<br>")

                        If destread.IndexOfAny(anyOf) < 0 Or lineread.IndexOfAny(anyOf) < 0 Then
                            If filetomanipulate.Exists(lineread) = True Then

                                If filetomanipulate.Exists(destread) = False Then
                                    filetomanipulate.Move(lineread, destread)
                                    Count_Renamed = Count_Renamed + 1
                                    filewriter.WriteLine("Action: Successfully Renamed<br>")
                                Else
                                    Count_Failed_Destination = Count_Failed_Destination + 1
                                    filewriter.WriteLine("Action: Rename Failed - Destination file already exists<br>")
                                End If

                            Else
                                Count_Failed_Source = Count_Failed_Source + 1
                                filewriter.WriteLine("Action: Rename Failed - Unable to locate source file<br>")
                            End If
                        Else
                            Count_Failed_Invalid_Character = Count_Failed_Invalid_Character + 1
                            filewriter.WriteLine("Action: Rename Failed - Invalid character present in file path<br>")
                        End If
                        filewriter.WriteLine("</li>")
                    End If
                    If (destread Is Nothing) Then
                        lineread = destread
                    Else
                        lineread = filereader.ReadLine
                    End If

                Loop
                filewriter.WriteLine("</ul>")

                filewriter.WriteLine("<p>")
                filewriter.WriteLine("Total Files Processed: " & Count_Total & " files" & "<br>")
                filewriter.WriteLine("Total Files Renamed: " & Count_Renamed & " files" & "<br>")
                filewriter.WriteLine("Total Rename Fails: " & (Count_Total - Count_Renamed) & " files" & "<br>")
                filewriter.WriteLine("<font color=""#C0C0C0"">")
                filewriter.WriteLine("&nbsp;&nbsp;&nbsp;Invalid Source Files: " & Count_Failed_Source & " files" & "<br>")
                filewriter.WriteLine("&nbsp;&nbsp;&nbsp;Destination Already Exists: " & Count_Failed_Destination & " files" & "<br>")
                filewriter.WriteLine("&nbsp;&nbsp;&nbsp;Invalid Character Sequence: " & Count_Failed_Invalid_Character & " files" & "<br>")
                filewriter.WriteLine("</font>")
                filewriter.WriteLine("</p>")

                filewriter.WriteLine("</body></html>")
                filewriter.Close()
                filereader.Close()

                Label1.Text = "Total Files Processed: " & Count_Total & " files"
                Label2.Text = "Total Files Renamed: " & Count_Renamed & " files"
                Label3.Text = "Total Rename Fails: " & (Count_Total - Count_Renamed) & " files"
                Label4.Text = "Invalid Source Files: " & Count_Failed_Source & " files"
                Label5.Text = "Destination Already Exists: " & Count_Failed_Destination & " files"
                Label6.Text = "Invalid Character Sequence: " & Count_Failed_Invalid_Character & " files"
                LinkLabel1.Visible = True
                Panel1.Visible = False
                MsgBox("Process Completed.", MsgBoxStyle.OKOnly, "Simple File Renamer 1.0")
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Simple File Renamer 1.0")
        End Try
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click
        Rename_File_Process()
    End Sub


    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim f As FileInfo
        f = New FileInfo(Application.ExecutablePath())
        System.Diagnostics.Process.Start(f.DirectoryName() & "\logfile.htm")
    End Sub

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        Try
            Me.Close()
            Me.Dispose()
        Catch et As Exception
            MsgBox(et.Message, MsgBoxStyle.Exclamation, "Simple File Renamer 1.0")
        End Try
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem6.Click
        Try
            Dim aboutscreen As New About
            Dim result As DialogResult
            result = aboutscreen.ShowDialog()
            aboutscreen.Dispose()
        Catch et As Exception
            MsgBox(et.Message, MsgBoxStyle.Exclamation, "Simple File Renamer 1.0")
        End Try
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        Try
            Dim helpscreen As New Help
            'Dim result As DialogResult
            'result = helpscreen.ShowDialog()
            helpscreen.Show()
            'helpscreen.Dispose()
        Catch et As Exception
            MsgBox(et.Message, MsgBoxStyle.Exclamation, "Simple File Renamer 1.0")
        End Try
    End Sub

    Private Sub MenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem7.Click
        String_Replace_Function()
    End Sub

    Private Sub String_Replace_Function()
        Try
            Dim result2 As DialogResult
            Dim accept_input As New Accept_Inputs
            result2 = accept_input.ShowDialog
            If result2 = DialogResult.OK Then
                Dim find As String
                Dim replace As String
                find = accept_input.Find.Text
                replace = accept_input.Replace.Text
                Dim include_extension As Boolean
                include_extension = accept_input.CheckBox1.Checked
                Panel1.Visible = True
                Dim result As DialogResult = FolderBrowserDialog1.ShowDialog()
                If result = DialogResult.OK Then


                    Dim destread As String
                    Dim filetomanipulate As File
                    Dim Count_Total, Count_Renamed, Count_Failed_Source, Count_Failed_Destination, Count_Failed_Invalid_Character As Integer
                    Count_Total = 0
                    Count_Renamed = 0
                    Count_Failed_Source = 0
                    Count_Failed_Destination = 0
                    Count_Failed_Invalid_Character = 0

                    Dim f As FileInfo
                    f = New FileInfo(Application.ExecutablePath())

                    Dim filewriter As New StreamWriter(f.DirectoryName() & "\logfile.htm", False, System.Text.Encoding.ASCII)



                    filewriter.WriteLine("<html>" & vbCrLf & "<body bgproperties=""fixed"" background=""" & f.DirectoryName() & "/Background_Image_Log_File.jpg" & """>" & vbCrLf & "<h1>Simple File Renamer 1.0 Log File</h1>")
                    filewriter.WriteLine("<h3>Process Started: " & Now & "</h3>")
                    filewriter.WriteLine("<p>Input File: " & OpenFileDialog1.FileName & "</p>")
                    filewriter.WriteLine("<ul>")

                    Dim foldercontents As DirectoryInfo
                    foldercontents = New DirectoryInfo(FolderBrowserDialog1.SelectedPath)
                    Dim filetocheck As FileInfo
                    Dim lineread As String
                    For Each filetocheck In foldercontents.GetFiles
                        lineread = filetocheck.FullName
                        Dim lineread_name As String = filetocheck.Name
                        Dim lineread_path = filetocheck.DirectoryName
                        'Do While Not lineread Is Nothing
                        Dim extension As String
                        extension = ""
                        If include_extension = False Then
                            extension = lineread_name.Substring(lineread_name.LastIndexOf("."), lineread_name.Length - lineread_name.LastIndexOf("."))
                            lineread_name = lineread_name.Remove(lineread_name.LastIndexOf("."), lineread_name.Length - lineread_name.LastIndexOf("."))
                        End If
                        destread = lineread_path & "\" & lineread_name.Replace(find, replace)
                        If include_extension = False Then

                            destread = destread & extension
                        End If
                        If IsNothing(destread) = False Then


                            Count_Total = Count_Total + 1
                            Dim target As String = "/*?""<>|"
                            Dim anyOf As Char() = target.ToCharArray()
                            filewriter.WriteLine("<li>Source: " & lineread & "<br>")
                            filewriter.WriteLine("Destination: " & destread & "<br>")

                            If destread.IndexOfAny(anyOf) < 0 Or lineread.IndexOfAny(anyOf) < 0 Then
                                If filetomanipulate.Exists(lineread) = True Then

                                    If filetomanipulate.Exists(destread) = False Then
                                        filetomanipulate.Move(lineread, destread)
                                        Count_Renamed = Count_Renamed + 1
                                        filewriter.WriteLine("Action: Successfully Renamed<br>")
                                    Else
                                        Count_Failed_Destination = Count_Failed_Destination + 1
                                        filewriter.WriteLine("Action: Rename Failed - Destination file already exists<br>")
                                    End If

                                Else
                                    Count_Failed_Source = Count_Failed_Source + 1
                                    filewriter.WriteLine("Action: Rename Failed - Unable to locate source file<br>")
                                End If
                            Else
                                Count_Failed_Invalid_Character = Count_Failed_Invalid_Character + 1
                                filewriter.WriteLine("Action: Rename Failed - Invalid character present in file path<br>")
                            End If
                            filewriter.WriteLine("</li>")
                        End If
                        ' Loop
                    Next
                    foldercontents = Nothing
                    filetocheck = Nothing
                    filewriter.WriteLine("</ul>")

                    filewriter.WriteLine("<p>")
                    filewriter.WriteLine("Total Files Processed: " & Count_Total & " files" & "<br>")
                    filewriter.WriteLine("Total Files Renamed: " & Count_Renamed & " files" & "<br>")
                    filewriter.WriteLine("Total Rename Fails: " & (Count_Total - Count_Renamed) & " files" & "<br>")
                    filewriter.WriteLine("<font color=""#C0C0C0"">")
                    filewriter.WriteLine("&nbsp;&nbsp;&nbsp;Invalid Source Files: " & Count_Failed_Source & " files" & "<br>")
                    filewriter.WriteLine("&nbsp;&nbsp;&nbsp;Destination Already Exists: " & Count_Failed_Destination & " files" & "<br>")
                    filewriter.WriteLine("&nbsp;&nbsp;&nbsp;Invalid Character Sequence: " & Count_Failed_Invalid_Character & " files" & "<br>")
                    filewriter.WriteLine("</font>")
                    filewriter.WriteLine("</p>")

                    filewriter.WriteLine("</body></html>")
                    filewriter.Close()
                    'filereader.Close()

                    Label1.Text = "Total Files Processed: " & Count_Total & " files"
                    Label2.Text = "Total Files Renamed: " & Count_Renamed & " files"
                    Label3.Text = "Total Rename Fails: " & (Count_Total - Count_Renamed) & " files"
                    Label4.Text = "Invalid Source Files: " & Count_Failed_Source & " files"
                    Label5.Text = "Destination Already Exists: " & Count_Failed_Destination & " files"
                    Label6.Text = "Invalid Character Sequence: " & Count_Failed_Invalid_Character & " files"
                    LinkLabel1.Visible = True
                    Panel1.Visible = False
                    MsgBox("Process Completed.", MsgBoxStyle.OKOnly, "Simple File Renamer 1.0")
                End If
            End If
            accept_input.Dispose()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Simple File Renamer 1.0")
        End Try
    End Sub
End Class
